from django.apps import AppConfig


class PingshanConfig(AppConfig):
    name = 'pingshan'
